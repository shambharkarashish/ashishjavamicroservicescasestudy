package com.virtusa.ecommerce.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.virtusa.ecommerce.models.Location;


public interface LocationRepository extends JpaRepository<Location, Long>{

}
