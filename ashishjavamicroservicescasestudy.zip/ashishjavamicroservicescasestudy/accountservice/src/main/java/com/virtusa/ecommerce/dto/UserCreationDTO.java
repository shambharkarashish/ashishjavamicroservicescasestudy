package com.virtusa.ecommerce.dto;

import lombok.Data;

@Data
public class UserCreationDTO {
	
 private String userName;
 private String password;
}
